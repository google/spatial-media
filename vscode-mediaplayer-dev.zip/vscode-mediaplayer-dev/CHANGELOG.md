# Change Log

## v1.6.4

- Added stop command 
- Enabled TreeItemCollapsibleState for track item on search view
- Added welcome content on the search track view
- Refactored the search, fav, local views code implementation

## v1.6.2

- Used node-mpv v2 package, so it fixes all load playlist commands from the view
- Used "googleapis" package to fix #31 issue (Youtube o is not a function)

## v1.6.1

- Fixed load podcast playlist