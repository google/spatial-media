# Security Policy

If you found a vulnerability please create an issue and discribe it.
